// All paths except vizuly/core get their own namespace as denoted by the _path.js file

// @version 1.1.20

vizuly.theme = {};
vizuly.skin = {};