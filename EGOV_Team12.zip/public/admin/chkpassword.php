<?php
// get_sorted_content.php
    if($_POST['password'] == "Auction@123")
    	echo "1"; // valid
    else
    	echo "0"; // invalid
?>